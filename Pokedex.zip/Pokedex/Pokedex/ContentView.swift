//
//  ContentView.swift
//  Pokedex
//
//  Created by Aluno Mack on 29/07/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
                        PokedexView()
                            .tabItem {
                                Label("Pokedex", systemImage: "magazine.fill")
                            }
                        StatisticsView()
                            .tabItem {
                                Label("Estatísticas", systemImage: "chart.xyaxis.line")
                            }
                    }
    }
}

#Preview {
    ContentView()
}
