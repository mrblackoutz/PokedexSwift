//
//  PokedexView.swift
//  Pokedex
//
//  Created by Aluno Mack on 29/07/25.
//

import SwiftUI

struct PokedexView: View {
    let columns = [
            GridItem(.flexible()),
            GridItem(.flexible()),
            GridItem(.flexible())
        ]
    
    var body: some View {
        ScrollView() {
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(pokemons) { pokemon in
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        VStack {
                            AsyncImage(url: URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/\(pokemon.id).png"))
                            Text(pokemon.name.capitalized)
                        }
                    }).buttonStyle(.bordered).buttonBorderShape(.roundedRectangle(radius: 10)
                        )
                }
                        }
                        .padding()
        }
    }
}

#Preview {
    PokedexView()
}
