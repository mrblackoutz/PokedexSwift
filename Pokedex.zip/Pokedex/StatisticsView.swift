//
//  StatisticsView.swift
//  Pokedex
//
//  Created by Aluno Mack on 29/07/25.
//

import SwiftUI

struct StatisticsView: View {
    var body: some View {
        Text("ESTATISTICAS!")
    }
}

#Preview {
    StatisticsView()
}
