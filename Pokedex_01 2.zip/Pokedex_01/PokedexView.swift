//
//  PokedexView.swift
//  Pokedex
//
//  Created by Aluno Mack on 29/07/25.
//

import SwiftUI

struct PokedexView: View {
    let columns = [
            GridItem(.flexible()),
            GridItem(.flexible()),
            GridItem(.flexible())
        ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(pokemons) { pokemon in
                                NavigationLink(destination: StatisticsView(pokemon: pokemon)){
                                    VStack {
                                        AsyncImage(url: URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/\(pokemon.id).png"))
                                        Text(pokemon.name.capitalized)
                                    }
                                }
                                
            
                        }
                    }
                    .padding()
                }
            
        }
    }
}

#Preview {
    PokedexView()
}
