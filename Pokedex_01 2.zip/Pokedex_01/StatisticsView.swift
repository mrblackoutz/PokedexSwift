//
//  StatisticsView.swift
//  Pokedex
//
//  Created by Aluno Mack on 29/07/25.
//

import SwiftUI

struct StatisticsView: View {
    
    let pokemon: Pokemon
    let zero: Int = 0
    
    var body: some View {
        VStack {
            if (pokemon.id <= 9) { AsyncImage(url: URL(string: "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/\(zero)\(zero)\(pokemon.id).png")) { image in image.image?.resizable().frame(width: 250, height: 300) }
            } else if (pokemon.id <= 99){ AsyncImage(url: URL(string: "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/\(zero)\(pokemon.id).png")) { image in image.image?.resizable().frame(width: 250, height: 300) }

            } else { AsyncImage(url: URL(string: "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/\(pokemon.id).png")) { image in image.image?.resizable().frame(width: 250, height: 300) }

            }
            
            VStack () {
                VStack {
                    Text("NOME").font(.caption).foregroundStyle(.secondary)
                    Text(pokemon.name.capitalized).font(.largeTitle).bold()
                }.padding(8)
                VStack {
                    Text("ID").font(.caption).foregroundStyle(.secondary)
                    Text("\(pokemon.id)").font(.largeTitle).fontWeight(.semibold)
                }.padding(8)
                HStack {
                    Text("TIPOS").font(.caption).foregroundStyle(.secondary)
                    ForEach(pokemon.types) { type in
                        ZStack {
                            RoundedRectangle(cornerSize: CGSize(width: 20, height: 20)).frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 50)
                            Text(type.rawValue).colorInvert()
                        }
                    }
                }
            }.padding(20)
        }
    }
}

#Preview {
        NavigationView{
            StatisticsView(pokemon: Pokemon(id: 1, name: "Sem nome", types: [ElementType.normal, ElementType.dark]))
        }
}
