//
//  StatisticsView.swift
//  Pokedex
//
//  Created by Aluno Mack on 29/07/25.
//

import SwiftUI

struct StatisticsView: View {
    
    let pokemon: Pokemon
    
    var body: some View {
        Text("\(pokemon.id)")
        Text(pokemon.name)
        Text(pokemon.types.first!.rawValue)
    }
}

#Preview {
    StatisticsView(pokemon: Pokemon(id: 1, name: "n", types: [.grass], url: ""))
}
